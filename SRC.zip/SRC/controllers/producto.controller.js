const Producto = require('../models/producto.model');
const Categoria = require('../models/categoria.model');
const crearPDF = require('../utils/pdfGenerator');
const fs = require('fs');
const path = require('path');

//metodo para crear un producto y guardarlo en la base de datos
exports.crearProducto = async (req, res) => {
    try {
        const { nombre, precio, descripcion, categoriaId } = req.body;

        const nuevoProducto = await Producto.create({ //definimos 
            nombre,
            precio,
            descripcion,
            categoriaId
        });
        res.status(201).json(nuevoProducto);

    } catch (error) { //se contempla el error al crear el producto
        res.status(500).json({
            mensaje: 'Error al crear el producto'
        });
    }
}
//metodo para obtener todos los productos de la base de datos
exports.obtenerProductos = async (req, res) => {
    try {
        const productos = await Producto.findAll({
            include: [{
                model: Categoria,
                as: 'categoria', // Alias explícito
                attributes: ['nombre']
            }]
        });
        res.status(200).json(productos);
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al obtener los productos'
        });
    }
}

//metodo para actualizar un producto existente
exports.actualizarProducto = async (req, res) => {
    try {
        const { id } = req.params; // ID del producto a actualizar
        const { nombre, precio, stock, categoriaId } = req.body; // Nuevos datos
        // 1. Buscamos el producto
        const producto = await Producto.findByPk(id);
        if (!producto) {
            return res.status(404).json({
                mensaje: 'Producto no encontrado'
            });
        }
        // 2. Actualizamos los campos
        producto.nombre = nombre || producto.nombre;
        producto.precio = precio || producto.precio;
        producto.stock = stock || producto.stock;
        producto.categoriaId = categoriaId || producto.categoriaId;
        // 3. Guardamos los cambios en la base de datos
        await producto.save();
        res.status(200).json({
            mensaje: 'Producto actualizado exitosamente',
            producto
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al actualizar el producto'
        });
    }
}

//metodo para eliminar un producto
exports.eliminarProducto = async (req, res) => {
    try {
        const { id } = req.params; // ID del producto a eliminar
        // Usamos el método destroy de Sequelize
        const filasEliminadas = await Producto.destroy({
            where: {
                id: id
            }
        });
        if (filasEliminadas === 0) {
            // Si no se eliminó ninguna fila, el producto no existía
            return res.status(404).json({
                mensaje: 'Producto no encontrado'
            });
        }
        res.status(200).json({
            mensaje: 'Producto eliminado exitosamente'
        });

    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al eliminar el producto'
        });
    }
}

//metodo para generar el reporte en PDF
exports.generarReporte = async (req, res) => {
    try {
        // Obtenemos solo los productos, igual que en la BD "tal cual"
        const productos = await Producto.findAll({ raw: true });

        // Mapear los productos al formato que espera el HBS
        const productsData = productos.map(p => ({
            id: p.id,
            nombre: p.nombre,
            descripcion: p.descripcion,
            categoriaId: p.categoriaId,
            precio: p.precio
        }));

        const dataReporte = {
            details: {
                nombreComercial: "Mi Empresa S.A.",
                ruc: "0102030405001",
                direccion: "Av. Siempre Viva 123",
                email: "info@miempresa.com"
            },
            date: new Date().toLocaleDateString(),
            products: productsData,
            totalItems: productsData.length,
            generatedBy: "Admin"
        };

        const pdfBuffer = await crearPDF(dataReporte);

        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', 'inline; filename=reporte-productos.pdf');
        res.send(pdfBuffer);

    } catch (error) {
        console.error(error);
        res.status(500).json({
            mensaje: 'Error al generar el reporte'
        });
    }
}

exports.generarReporteLocal = async (req, res) => {
    try {
        console.log('Generando reporte local...');

        // 1. Obtener todos los productos de la base de datos "tal cual"
        const productos = await Producto.findAll({ raw: true });

        if (productos.length > 0) {
            fs.writeFileSync('C:\\api-rest-nodejs\\debug_keys.txt', 'Keys: ' + Object.keys(productos[0]).join(', '));
        }

        if (!productos || productos.length === 0) {
            return res.status(404).json({ message: 'No hay productos para generar el reporte' });
        }

        // Convertir instancias de Sequelize a objetos planos
        const productsData = productos.map(p => {
            return {
                ...p,
                // Ya no mapeamos categoria.nombre porque no se pidió
                categoriaId: p.categoriaId
            };
        });

        // 2. Preparar los datos para la plantilla (bill.hbs)
        console.log('Datos procesados para PDF:', JSON.stringify(productsData, null, 2));
        const datosReporte = {
            details: {
                nombreComercial: "Mi Empresa S.A.",
                ruc: "0102030405001",
                direccion: "Dirección de la Empresa",
                email: "contacto@miempresa.com"
            },
            date: new Date().toLocaleDateString(),
            totalItems: productsData.length,
            generatedBy: "Sistema de Reportes",
            products: productsData
        };

        // 3. Generar el PDF
        const pdfBuffer = await crearPDF(datosReporte);

        // 4. Guardar archivo localmente
        // Crear carpeta 'reportes' en la raíz si no existe
        const reportesDir = path.join(__dirname, '../../reportes');
        if (!fs.existsSync(reportesDir)) {
            fs.mkdirSync(reportesDir);
        }

        const fileName = `reporte_productos_${Date.now()}.pdf`;
        const filePath = path.join(reportesDir, fileName);

        fs.writeFileSync(filePath, pdfBuffer);
        console.log(`PDF guardado en: ${filePath}`);

        res.json({
            message: 'Reporte generado y guardado exitosamente',
            path: filePath,
            fileName: fileName,
            count: productsData.length
        });

    } catch (error) {
        console.error('Error generando reporte local:', error);
        res.status(500).json({
            message: 'Error al generar reporte local',
            error: error.message
        });
    }
};
