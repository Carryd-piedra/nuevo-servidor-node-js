const fs = require('fs');
const path = require('path');
const hbs = require('handlebars');
const puppeteer = require('puppeteer');

const crearPDF = async (datosFactura) => {

    const filePath = path.join(__dirname, 'bill.hbs');
    const htmlTemplate = fs.readFileSync(filePath, 'utf-8');

    const template = hbs.compile(htmlTemplate);
    const htmlFinal = template(datosFactura);

    const browser = await puppeteer.launch();
    const page = await browser.newPage();

    await page.setContent(htmlFinal, { waitUntil: 'networkidle0' });

    const pdfBuffer = await page.pdf({
        format: 'A4',
        printBackground: true
    });

    await browser.close();
    return pdfBuffer;
};

module.exports = crearPDF;

